
library(caret)
library(rpart)

# Load the data
data(crop, package = "datasets")
data <- crop  # Assuming 'crop' dataset has appropriate features

# Assuming 'data' has a column 'Outcome' as the target variable
# Split data into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(data$Outcome, p = 0.75, list = TRUE, times = 1)
train <- data[trainIndex[[1]],]
test <- data[-trainIndex[[1]],]

# Train a decision tree model
model <- rpart(Outcome ~ ., data = train)

# Make predictions
predictions <- predict(model, test, type = "class")

# Evaluate the model
confusionMatrix(predictions, test$Outcome)
